# QuestMate — Android prototype

A mobile companion for OSRS quest guidance.

## Current prototype
- Android app shell
- Floating overlay using Android's system overlay permission
- Movable overlay window
- Demo quest step UI
- No automated game input
- Architecture ready for a real quest database and step engine

## Build
Open this folder in Android Studio and build the `app` module.

## Next development
1. Add a local JSON/SQLite quest database.
2. Add all quest requirements and original walkthrough content.
3. Add search/filter and per-quest progress.
4. Add maps and destination links.
5. Add overlay controls and persistent progress.
6. Add an updateable content package.

The prototype deliberately does not inject into or modify the OSRS client and does not send game input.
