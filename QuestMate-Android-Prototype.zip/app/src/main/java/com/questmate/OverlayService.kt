package com.questmate

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var view: View? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (view != null) return START_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 22, 28, 22)
            setBackgroundColor(Color.argb(235, 20, 20, 24))
        }
        val title = TextView(this).apply {
            text = "QUESTMATE  •  Demo"
            textSize = 18f
            setTextColor(Color.WHITE)
        }
        val step = TextView(this).apply {
            text = "Dragon Slayer I\n\nCURRENT STEP\nTalk to the Guildmaster in the Champions' Guild.\n\nITEMS\n✓ 10,000 gp\n✓ 3 planks\n\nNEXT\n→ Champions' Guild"
            textSize = 15f
            setTextColor(Color.WHITE)
        }
        val done = TextView(this).apply {
            text = "     DONE     "
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 18, 0, 0)
            setOnClickListener { stopSelf() }
        }
        box.addView(title); box.addView(step); box.addView(done)

        val type = if (android.os.Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.END
        p.x = 20; p.y = 140

        box.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=p.x; startY=p.y; return true }
                    MotionEvent.ACTION_MOVE -> { p.x=startX+(downX-e.rawX).toInt(); p.y=startY+(e.rawY-downY).toInt(); wm.updateViewLayout(v,p); return true }
                }
                return false
            }
        })
        view = box
        wm.addView(box, p)
        return START_STICKY
    }

    override fun onDestroy() {
        view?.let { wm.removeView(it) }
        view = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
