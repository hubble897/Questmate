package com.questmate

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        val title = TextView(this).apply {
            text = "QuestMate\nOSRS Mobile Quest Companion"
            textSize = 26f
        }
        val info = TextView(this).apply {
            text = "\nPrototype: quest search, step tracking and floating guidance overlay.\n\nThe overlay is informational only and does not automate game input."
            textSize = 16f
        }
        val overlay = Button(this).apply { text = "Enable Floating Overlay" }
        val demo = Button(this).apply { text = "Open Demo Quest" }

        overlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, OverlayService::class.java))
            }
        }
        demo.setOnClickListener { startService(Intent(this, OverlayService::class.java)) }

        root.addView(title)
        root.addView(info)
        root.addView(demo)
        root.addView(overlay)
        setContentView(root)
    }
}
